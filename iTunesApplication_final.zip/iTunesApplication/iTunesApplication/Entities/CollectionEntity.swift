//
//  CollectionEntity.swift
//  iTunesApplication
//
//  Created by M Lavrenov on 16/11/2023.
//

import Foundation

struct CollectionEntity: Decodable {
    var Spectrums: [SpectrumEntity]
}
